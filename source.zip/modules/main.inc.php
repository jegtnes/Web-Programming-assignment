<?php # main.inc.php

/* 
 *	main.inc.php -
 *	The home page, essentially.
 */

?>

	  <h2>Oh hi!</h2>
	  <p>Welcome to The Ultimate Sci-Fi Parlour, providing you with nothing but the very best of Sci-fi books and films since 1688.</p>